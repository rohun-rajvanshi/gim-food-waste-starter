GIM Mess Forecasting — Overleaf Project
=======================================

How to use:
1) Upload this ZIP to Overleaf as a new project.
2) Open main.tex and fill:
   - Title and author block (names/emails)
   - GitHub link in the Reproducibility section
   - Performance numbers in Table 1
3) Replace fig_avp_placeholder.png with your Actual-vs-Predicted plot exported from Colab.
4) If you prefer BibTeX, uncomment the two lines under the Conclusion and edit refs.bib.
5) Keep within your page limit (e.g., 6 pages).

Tip: Generate your plot in Colab as PNG named 'fig_avp_placeholder.png' and re-upload to Overleaf.
Generated on: 2025-10-05
